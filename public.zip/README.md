# supermall

![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(1).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(2).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(3).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(4).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(5).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(6).png>)
![蘑菇街](<https://gitee.com/pengnima1/blogimage/raw/master/md/mgj(7).png>)

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn serve
```

### Compiles and minifies for production

```
yarn build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
