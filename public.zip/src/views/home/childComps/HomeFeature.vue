<template>
  <div class="feature">
    <a href="http://localhost:8080/home/#feature">
      <img src="~assets/img/home/recommend_bg.jpg" alt="" />
    </a>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.feature img {
  width: 100%;
}
</style>
