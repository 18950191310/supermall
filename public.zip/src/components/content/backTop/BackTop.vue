<template>
  <div class="back_top">
    <img src="~assets/img/common/top.png" alt="" />
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.back_top {
  position: fixed;
  right: 0.64rem;
  bottom: 2.13rem;
}
.back_top img {
  width: 1.83rem;
  height: 1.83rem;
}
</style>
