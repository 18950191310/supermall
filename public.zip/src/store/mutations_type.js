export const ADD_CARTCOUNT = "addCartCount";
export const ADD_CARTLIST = "addCartList";
export const CHANGE_UID = "changeUid";
